# Zabbix Alertas App (Flutter)

Aplicativo Android focado **somente** nos links **COMEP** e **NETWAY**.

### O que o app faz

- Conecta na API do Zabbix
- Mostra apenas alertas/quedas dos hosts configurados
- Exibe:
  - Nome do link
  - Motivo da queda (texto do problema do Zabbix)
  - Severidade (com cor e emoji)
  - Horário
  - Localização (você configura)
- Notificações locais no celular quando aparece novo alerta
- Atualização automática a cada 45 segundos

---

## Como gerar o APK

### 1. Pré-requisitos

- Flutter SDK instalado ([flutter.dev](https://flutter.dev))
- Android Studio
- Conta Google (para Firebase – opcional, mas recomendado para push em background)

### 2. Abrir o projeto

```bash
cd zabbix_alertas_app
flutter pub get
```

### 3. Configurar Firebase (recomendado para notificações em segundo plano)

1. Acesse [console.firebase.google.com](https://console.firebase.google.com)
2. Crie um projeto
3. Adicione um app Android (package name: `com.exemplo.zabbix_alertas_app`)
4. Baixe o arquivo `google-services.json`
5. Coloque em: `android/app/google-services.json`
6. Siga as instruções do FlutterFire para completar a configuração

> Se não configurar o Firebase agora, o app ainda funciona com notificações locais enquanto estiver aberto.

### 4. Gerar o APK

```bash
# APK de debug (teste)
flutter build apk --debug

# APK de release (para instalar de verdade)
flutter build apk --release
```

O arquivo fica em:
```
build/app/outputs/flutter-apk/app-release.apk
```

### 5. Instalar no celular

- Ative “Fontes desconhecidas” nas configurações do Android
- Transfira o APK e instale

---

## Configuração dentro do app

1. Abra o app
2. Toque no ícone de **engrenagem** (Configurações)
3. Preencha:
   - URL da API: `http://IP_DO_ZABBIX/api_jsonrpc.php`
   - Usuário e senha (com permissão de leitura)
   - Hosts: `COMEP,NETWAY`
   - Localização de cada link
4. Salve

Pronto! O app começa a monitorar.

---

## Estrutura do projeto

```
lib/
  main.dart
  models/alert_model.dart
  services/
    zabbix_service.dart      ← lógica da API do Zabbix
    notification_service.dart
  screens/
    home_screen.dart         ← lista de alertas
    alert_detail_screen.dart ← detalhes (motivo + localização)
    settings_screen.dart     ← configurações
```

---

## Observações importantes

- O app **não precisa** de root.
- Funciona com Zabbix 5.x, 6.x e 7.x.
- As notificações locais funcionam enquanto o app estiver em primeiro plano ou recentemente aberto.
- Para notificações mesmo com o app fechado, é necessário configurar o Firebase Cloud Messaging.

Qualquer dúvida na compilação, é só perguntar.
