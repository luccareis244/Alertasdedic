import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/alert_model.dart';

class AlertDetailScreen extends StatelessWidget {
  const AlertDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final alert = ModalRoute.of(context)!.settings.arguments as AlertModel;
    final dateFormat = DateFormat('dd/MM/yyyy HH:mm:ss');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalhes do Alerta'),
        backgroundColor: const Color(0xFF161B22),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Severidade
            Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: alert.severityColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: alert.severityColor, width: 2),
                ),
                child: Text(
                  '${alert.severityEmoji}  ${alert.severityName.toUpperCase()}',
                  style: TextStyle(
                    color: alert.severityColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 28),

            _buildSection(
              icon: Icons.router,
              title: 'Link / Host',
              content: alert.hostName,
              subtitle: alert.hostTechnical.isNotEmpty ? alert.hostTechnical : null,
            ),

            _buildSection(
              icon: Icons.warning_amber_rounded,
              title: 'Motivo da queda / Problema',
              content: alert.name,
            ),

            if (alert.description != null && alert.description!.isNotEmpty)
              _buildSection(
                icon: Icons.info_outline,
                title: 'Detalhes adicionais',
                content: alert.description!,
              ),

            _buildSection(
              icon: Icons.location_on,
              title: 'Localização',
              content: alert.location ?? 'Não configurada',
            ),

            _buildSection(
              icon: Icons.access_time,
              title: 'Horário do evento',
              content: dateFormat.format(alert.clock),
            ),

            _buildSection(
              icon: Icons.tag,
              title: 'ID do Evento',
              content: alert.eventId,
            ),

            const SizedBox(height: 20),
            const Divider(color: Colors.white12),
            const SizedBox(height: 12),
            const Text(
              'Esta informação é coletada diretamente da API do Zabbix em tempo real.',
              style: TextStyle(color: Colors.white38, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({
    required IconData icon,
    required String title,
    required String content,
    String? subtitle,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.blue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: Colors.blueAccent, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  content,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(color: Colors.white38, fontSize: 13),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
