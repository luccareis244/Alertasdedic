import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/zabbix_service.dart';
import '../models/alert_model.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alertas - Links'),
        backgroundColor: const Color(0xFF161B22),
        actions: [
          // Botão de Notificações (liga/desliga)
          Consumer<ZabbixService>(
            builder: (context, service, _) {
              return IconButton(
                tooltip: service.notificationsEnabled
                    ? 'Notificações ATIVADAS'
                    : 'Notificações DESATIVADAS',
                icon: Icon(
                  service.notificationsEnabled
                      ? Icons.notifications_active
                      : Icons.notifications_off,
                  color: service.notificationsEnabled
                      ? Colors.greenAccent
                      : Colors.redAccent,
                ),
                onPressed: () async {
                  await service.toggleNotifications();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          service.notificationsEnabled
                              ? 'Notificações ativadas'
                              : 'Notificações desativadas',
                        ),
                        duration: const Duration(seconds: 2),
                        backgroundColor: service.notificationsEnabled
                            ? Colors.green
                            : Colors.redAccent,
                      ),
                    );
                  }
                },
              );
            },
          ),
          IconButton(
            tooltip: 'Histórico de alertas',
            icon: const Icon(Icons.history),
            onPressed: () => Navigator.pushNamed(context, '/history'),
          ),
          IconButton(
            tooltip: 'Atualizar agora',
            icon: const Icon(Icons.refresh),
            onPressed: () {
              context.read<ZabbixService>().fetchAlerts();
            },
          ),
          IconButton(
            tooltip: 'Configurações',
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          ),
        ],
      ),
      body: Consumer<ZabbixService>(
        builder: (context, service, _) {
          if (!service.isConfigured) {
            return _buildNotConfigured(context);
          }

          if (service.isLoading && service.alerts.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }

          if (service.error != null && service.alerts.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 64, color: Colors.redAccent),
                    const SizedBox(height: 16),
                    Text(
                      service.error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: () => service.fetchAlerts(),
                      child: const Text('Tentar novamente'),
                    ),
                  ],
                ),
              ),
            );
          }

          if (service.alerts.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check_circle_outline, size: 80, color: Colors.green.shade400),
                  const SizedBox(height: 16),
                  const Text(
                    'Nenhum alerta ativo',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Links: ${service.hostsInteresse.join(", ")}',
                    style: const TextStyle(color: Colors.white54),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Severidade mínima: ${_severityLabel(service.minSeverity)}',
                    style: const TextStyle(color: Colors.white38, fontSize: 13),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    service.notificationsEnabled
                        ? '🔔 Notificações ativas'
                        : '🔕 Notificações desativadas',
                    style: TextStyle(
                      color: service.notificationsEnabled
                          ? Colors.greenAccent
                          : Colors.redAccent,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            );
          }

          return Column(
            children: [
              // Barra de status
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                color: const Color(0xFF161B22),
                child: Row(
                  children: [
                    Icon(
                      service.notificationsEnabled
                          ? Icons.notifications_active
                          : Icons.notifications_off,
                      size: 16,
                      color: service.notificationsEnabled
                          ? Colors.greenAccent
                          : Colors.redAccent,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      service.notificationsEnabled ? 'Notif. ON' : 'Notif. OFF',
                      style: TextStyle(
                        fontSize: 12,
                        color: service.notificationsEnabled
                            ? Colors.greenAccent
                            : Colors.redAccent,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '${service.alerts.length} alerta(s) • a cada ${service.pollIntervalSeconds}s',
                      style: const TextStyle(fontSize: 12, color: Colors.white54),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: () => service.fetchAlerts(),
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: service.alerts.length,
                    itemBuilder: (context, index) {
                      final alert = service.alerts[index];
                      return _AlertCard(alert: alert);
                    },
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  String _severityLabel(int sev) {
    const map = {
      0: 'Todas',
      1: 'Informação+',
      2: 'Aviso+',
      3: 'Média+',
      4: 'Alta+',
      5: 'Só Desastre',
    };
    return map[sev] ?? 'Aviso+';
  }

  Widget _buildNotConfigured(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.settings_suggest, size: 80, color: Colors.blueAccent),
            const SizedBox(height: 24),
            const Text(
              'Configure o Zabbix',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              'Informe a URL da API, usuário e senha para começar a receber os alertas dos links COMEP e NETWAY.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: () => Navigator.pushNamed(context, '/settings'),
              icon: const Icon(Icons.settings),
              label: const Text('Ir para Configurações'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AlertCard extends StatelessWidget {
  final AlertModel alert;

  const _AlertCard({required this.alert});

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd/MM/yyyy HH:mm:ss');

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          Navigator.pushNamed(
            context,
            '/alert-detail',
            arguments: alert,
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: alert.severityColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: alert.severityColor),
                    ),
                    child: Text(
                      '${alert.severityEmoji} ${alert.severityName}',
                      style: TextStyle(
                        color: alert.severityColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  if (alert.isResolved) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'RESOLVIDO',
                        style: TextStyle(
                          color: Colors.greenAccent,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                  const Spacer(),
                  Text(
                    dateFormat.format(alert.clock),
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                alert.hostName,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                alert.name,
                style: const TextStyle(color: Colors.white70, fontSize: 15),
              ),
              if (alert.location != null) ...[
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(Icons.location_on, size: 16, color: Colors.blueAccent),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        alert.location!,
                        style: const TextStyle(color: Colors.blueAccent, fontSize: 13),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
