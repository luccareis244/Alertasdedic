import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/zabbix_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _urlController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();
  final _hostsController = TextEditingController();
  final _locComePController = TextEditingController();
  final _locNetwayController = TextEditingController();

  bool _obscurePass = true;
  bool _saving = false;

  // Opções de monitoramento
  bool _notificationsEnabled = true;
  int _minSeverity = 2;
  int _pollInterval = 45;
  bool _showResolved = false;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;

  @override
  void initState() {
    super.initState();
    final service = context.read<ZabbixService>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _hostsController.text = service.hostsInteresse.join(',');
      _locComePController.text = service.locations['COMEP'] ?? '';
      _locNetwayController.text = service.locations['NETWAY'] ?? '';
      setState(() {
        _notificationsEnabled = service.notificationsEnabled;
        _minSeverity = service.minSeverity;
        _pollInterval = service.pollIntervalSeconds;
        _showResolved = service.showResolved;
        _soundEnabled = service.soundEnabled;
        _vibrationEnabled = service.vibrationEnabled;
      });
    });
  }

  @override
  void dispose() {
    _urlController.dispose();
    _userController.dispose();
    _passController.dispose();
    _hostsController.dispose();
    _locComePController.dispose();
    _locNetwayController.dispose();
    super.dispose();
  }

  Future<void> _salvar() async {
    if (_urlController.text.trim().isEmpty ||
        _userController.text.trim().isEmpty ||
        _passController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preencha URL, usuário e senha')),
      );
      return;
    }

    setState(() => _saving = true);

    final hosts = _hostsController.text
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final locations = {
      'COMEP': _locComePController.text.trim().isEmpty
          ? 'Localização COMEP não configurada'
          : _locComePController.text.trim(),
      'NETWAY': _locNetwayController.text.trim().isEmpty
          ? 'Localização NETWAY não configurada'
          : _locNetwayController.text.trim(),
    };

    await context.read<ZabbixService>().saveConfig(
          url: _urlController.text.trim(),
          user: _userController.text.trim(),
          password: _passController.text,
          hosts: hosts.isEmpty ? ['COMEP', 'NETWAY'] : hosts,
          locations: locations,
          notificationsEnabled: _notificationsEnabled,
          minSeverity: _minSeverity,
          pollIntervalSeconds: _pollInterval,
          showResolved: _showResolved,
          soundEnabled: _soundEnabled,
          vibrationEnabled: _vibrationEnabled,
        );

    setState(() => _saving = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Configurações salvas com sucesso!'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context);
    }
  }

  Future<void> _testarNotificacao() async {
    await context.read<ZabbixService>().sendTestNotification();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Notificação de teste enviada!'),
          backgroundColor: Colors.blueAccent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Configurações'),
        backgroundColor: const Color(0xFF161B22),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // ========== CONEXÃO ZABBIX ==========
          _sectionTitle('Conexão com o Zabbix'),
          const SizedBox(height: 12),
          TextField(
            controller: _urlController,
            decoration: const InputDecoration(
              labelText: 'URL da API do Zabbix',
              hintText: 'http://ip-do-zabbix/api_jsonrpc.php',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.link),
            ),
            keyboardType: TextInputType.url,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _userController,
            decoration: const InputDecoration(
              labelText: 'Usuário',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _passController,
            obscureText: _obscurePass,
            decoration: InputDecoration(
              labelText: 'Senha',
              border: const OutlineInputBorder(),
              prefixIcon: const Icon(Icons.lock),
              suffixIcon: IconButton(
                icon: Icon(_obscurePass ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _obscurePass = !_obscurePass),
              ),
            ),
          ),

          const SizedBox(height: 28),

          // ========== LINKS ==========
          _sectionTitle('Links monitorados'),
          const SizedBox(height: 8),
          const Text(
            'Separe por vírgula. O app só mostrará alertas desses hosts.',
            style: TextStyle(color: Colors.white54, fontSize: 13),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _hostsController,
            decoration: const InputDecoration(
              labelText: 'Hosts / Links',
              hintText: 'COMEP,NETWAY',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.router),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _locComePController,
            decoration: const InputDecoration(
              labelText: 'Localização COMEP',
              hintText: 'Ex: São Paulo - Data Center Centro',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.location_on),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _locNetwayController,
            decoration: const InputDecoration(
              labelText: 'Localização NETWAY',
              hintText: 'Ex: Rio de Janeiro - POP Barra',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.location_on),
            ),
          ),

          const SizedBox(height: 28),

          // ========== NOTIFICAÇÕES ==========
          _sectionTitle('Notificações'),
          const SizedBox(height: 8),
          SwitchListTile(
            title: const Text('Ativar notificações'),
            subtitle: const Text('Receber alertas no celular'),
            value: _notificationsEnabled,
            activeColor: Colors.greenAccent,
            onChanged: (v) => setState(() => _notificationsEnabled = v),
          ),
          SwitchListTile(
            title: const Text('Som'),
            subtitle: const Text('Tocar som ao receber alerta'),
            value: _soundEnabled,
            activeColor: Colors.greenAccent,
            onChanged: _notificationsEnabled
                ? (v) => setState(() => _soundEnabled = v)
                : null,
          ),
          SwitchListTile(
            title: const Text('Vibração'),
            subtitle: const Text('Vibrar ao receber alerta'),
            value: _vibrationEnabled,
            activeColor: Colors.greenAccent,
            onChanged: _notificationsEnabled
                ? (v) => setState(() => _vibrationEnabled = v)
                : null,
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _testarNotificacao,
            icon: const Icon(Icons.notification_add),
            label: const Text('Enviar notificação de teste'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.blueAccent,
              side: const BorderSide(color: Colors.blueAccent),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),

          const SizedBox(height: 28),

          // ========== OPÇÕES DE MONITORAMENTO ==========
          _sectionTitle('Opções de monitoramento'),
          const SizedBox(height: 12),

          // Severidade mínima
          const Text('Severidade mínima', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 6),
          DropdownButtonFormField<int>(
            value: _minSeverity,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            dropdownColor: const Color(0xFF161B22),
            items: const [
              DropdownMenuItem(value: 0, child: Text('0 - Todas')),
              DropdownMenuItem(value: 1, child: Text('1 - Informação e acima')),
              DropdownMenuItem(value: 2, child: Text('2 - Aviso e acima')),
              DropdownMenuItem(value: 3, child: Text('3 - Média e acima')),
              DropdownMenuItem(value: 4, child: Text('4 - Alta e acima')),
              DropdownMenuItem(value: 5, child: Text('5 - Só Desastre')),
            ],
            onChanged: (v) {
              if (v != null) setState(() => _minSeverity = v);
            },
          ),

          const SizedBox(height: 20),

          // Intervalo de verificação
          Text(
            'Intervalo de verificação: $_pollInterval segundos',
            style: const TextStyle(color: Colors.white70),
          ),
          Slider(
            value: _pollInterval.toDouble(),
            min: 15,
            max: 300,
            divisions: 19,
            label: '$_pollInterval s',
            activeColor: Colors.blueAccent,
            onChanged: (v) => setState(() => _pollInterval = v.round()),
          ),
          const Text(
            'Quanto menor o intervalo, mais rápido detecta quedas (consome mais bateria).',
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),

          const SizedBox(height: 16),

          SwitchListTile(
            title: const Text('Mostrar problemas resolvidos'),
            subtitle: const Text('Exibir também alertas já solucionados'),
            value: _showResolved,
            activeColor: Colors.greenAccent,
            onChanged: (v) => setState(() => _showResolved = v),
          ),

          const SizedBox(height: 36),

          // Botão Salvar
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: _saving ? null : _salvar,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
              ),
              child: _saving
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : const Text('Salvar Configurações', style: TextStyle(fontSize: 16)),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.bold,
        color: Colors.blueAccent,
      ),
    );
  }
}
