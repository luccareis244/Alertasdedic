import 'package:flutter/material.dart';

class AlertModel {
  final String eventId;
  final String name;
  final String severity;
  final String severityName;
  final String hostName;
  final String hostTechnical;
  final DateTime clock;
  final String? location;
  final bool isResolved;
  final String? description;
  final DateTime? resolvedAt;

  AlertModel({
    required this.eventId,
    required this.name,
    required this.severity,
    required this.severityName,
    required this.hostName,
    required this.hostTechnical,
    required this.clock,
    this.location,
    this.isResolved = false,
    this.description,
    this.resolvedAt,
  });

  factory AlertModel.fromZabbix(Map<String, dynamic> json, {String? location}) {
    final hosts = json['hosts'] as List? ?? [];
    final host = hosts.isNotEmpty ? hosts[0] : {};
    final sev = json['severity']?.toString() ?? '0';

    return AlertModel(
      eventId: json['eventid']?.toString() ?? '',
      name: json['name']?.toString() ?? 'Problema desconhecido',
      severity: sev,
      severityName: _severityName(sev),
      hostName: host['name']?.toString() ?? 'Desconhecido',
      hostTechnical: host['host']?.toString() ?? '',
      clock: DateTime.fromMillisecondsSinceEpoch(
        (int.tryParse(json['clock']?.toString() ?? '0') ?? 0) * 1000,
      ),
      location: location,
      isResolved: json['r_eventid'] != null && json['r_eventid'].toString() != '0',
      description: json['opdata']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'eventId': eventId,
      'name': name,
      'severity': severity,
      'severityName': severityName,
      'hostName': hostName,
      'hostTechnical': hostTechnical,
      'clock': clock.millisecondsSinceEpoch,
      'location': location,
      'isResolved': isResolved,
      'description': description,
      'resolvedAt': resolvedAt?.millisecondsSinceEpoch,
    };
  }

  factory AlertModel.fromJson(Map<String, dynamic> json) {
    return AlertModel(
      eventId: json['eventId']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      severity: json['severity']?.toString() ?? '0',
      severityName: json['severityName']?.toString() ?? _severityName(json['severity']?.toString() ?? '0'),
      hostName: json['hostName']?.toString() ?? '',
      hostTechnical: json['hostTechnical']?.toString() ?? '',
      clock: DateTime.fromMillisecondsSinceEpoch(json['clock'] as int? ?? 0),
      location: json['location']?.toString(),
      isResolved: json['isResolved'] as bool? ?? false,
      description: json['description']?.toString(),
      resolvedAt: json['resolvedAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(json['resolvedAt'] as int)
          : null,
    );
  }

  static String _severityName(String sev) {
    const map = {
      '0': 'Não classificado',
      '1': 'Informação',
      '2': 'Aviso',
      '3': 'Média',
      '4': 'Alta',
      '5': 'Desastre',
    };
    return map[sev] ?? sev;
  }

  Color get severityColor {
    switch (severity) {
      case '5':
        return const Color(0xFFE53935);
      case '4':
        return const Color(0xFFFF5722);
      case '3':
        return const Color(0xFFFF9800);
      case '2':
        return const Color(0xFFFFEB3B);
      case '1':
        return const Color(0xFF2196F3);
      default:
        return const Color(0xFF9E9E9E);
    }
  }

  String get severityEmoji {
    switch (severity) {
      case '5':
        return '🆘';
      case '4':
        return '🔴';
      case '3':
        return '🟠';
      case '2':
        return '🟡';
      case '1':
        return '🔵';
      default:
        return '⚪';
    }
  }
}
