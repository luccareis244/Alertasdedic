import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../models/alert_model.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();
    const settings = InitializationSettings(android: android, iOS: ios);

    await _plugin.initialize(settings);

    const channel = AndroidNotificationChannel(
      'zabbix_alerts',
      'Alertas Zabbix',
      description: 'Notificações de quedas e alertas dos links COMEP e NETWAY',
      importance: Importance.high,
      playSound: true,
      enableVibration: true,
    );

    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  Future<void> showAlertNotification(
    AlertModel alert, {
    bool playSound = true,
    bool vibrate = true,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'zabbix_alerts',
      'Alertas Zabbix',
      channelDescription: 'Alertas dos links monitorados',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      playSound: playSound,
      enableVibration: vibrate,
      styleInformation: BigTextStyleInformation(
        '${alert.severityEmoji} ${alert.name}\n\n'
        'Local: ${alert.location ?? "Não informado"}\n'
        'Host: ${alert.hostName}\n'
        'Severidade: ${alert.severityName}',
        contentTitle: '${alert.severityEmoji} Queda / Alerta - ${alert.hostName}',
      ),
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _plugin.show(
      alert.eventId.hashCode,
      '${alert.severityEmoji} ${alert.hostName}',
      alert.name,
      details,
    );
  }
}
