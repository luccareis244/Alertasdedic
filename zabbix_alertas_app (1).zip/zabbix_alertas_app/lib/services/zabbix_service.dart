import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/alert_model.dart';
import 'notification_service.dart';

class ZabbixService extends ChangeNotifier {
  String _url = '';
  String _user = '';
  String _password = '';
  String _authToken = '';
  List<String> _hostsInteresse = ['COMEP', 'NETWAY'];
  Map<String, String> _locations = {
    'COMEP': 'Localização COMEP (configure nas configurações)',
    'NETWAY': 'Localização NETWAY (configure nas configurações)',
  };

  bool _notificationsEnabled = true;
  int _minSeverity = 2;
  int _pollIntervalSeconds = 45;
  bool _showResolved = false;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;

  List<AlertModel> _alerts = [];
  List<AlertModel> _history = []; // Histórico de alertas
  bool _isLoading = false;
  String? _error;
  Timer? _timer;
  final Set<String> _notifiedEventIds = {};
  final Set<String> _historyEventIds = {}; // para evitar duplicatas no histórico

  // Getters
  List<AlertModel> get alerts => _alerts;
  List<AlertModel> get history => List.unmodifiable(_history);
  bool get isLoading => _isLoading;
  String? get error => _error;
  List<String> get hostsInteresse => _hostsInteresse;
  Map<String, String> get locations => _locations;
  bool get isConfigured => _url.isNotEmpty && _user.isNotEmpty && _password.isNotEmpty;

  bool get notificationsEnabled => _notificationsEnabled;
  int get minSeverity => _minSeverity;
  int get pollIntervalSeconds => _pollIntervalSeconds;
  bool get showResolved => _showResolved;
  bool get soundEnabled => _soundEnabled;
  bool get vibrationEnabled => _vibrationEnabled;

  ZabbixService() {
    _loadConfig();
  }

  Future<void> _loadConfig() async {
    final prefs = await SharedPreferences.getInstance();
    _url = prefs.getString('zabbix_url') ?? '';
    _user = prefs.getString('zabbix_user') ?? '';
    _password = prefs.getString('zabbix_password') ?? '';
    _hostsInteresse = prefs.getStringList('hosts_interesse') ?? ['COMEP', 'NETWAY'];

    final locComeP = prefs.getString('loc_COMEP');
    final locNetway = prefs.getString('loc_NETWAY');
    if (locComeP != null) _locations['COMEP'] = locComeP;
    if (locNetway != null) _locations['NETWAY'] = locNetway;

    _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
    _minSeverity = prefs.getInt('min_severity') ?? 2;
    _pollIntervalSeconds = prefs.getInt('poll_interval') ?? 45;
    _showResolved = prefs.getBool('show_resolved') ?? false;
    _soundEnabled = prefs.getBool('sound_enabled') ?? true;
    _vibrationEnabled = prefs.getBool('vibration_enabled') ?? true;

    // Carrega histórico
    await _loadHistory();

    notifyListeners();

    if (isConfigured) {
      startPolling();
    }
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('alerts_history');
    if (raw == null || raw.isEmpty) return;

    try {
      final List list = jsonDecode(raw);
      _history = list
          .map((e) => AlertModel.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      // Ordena do mais recente para o mais antigo
      _history.sort((a, b) => b.clock.compareTo(a.clock));
      _historyEventIds.addAll(_history.map((a) => a.eventId));
    } catch (e) {
      debugPrint('Erro ao carregar histórico: $e');
      _history = [];
    }
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    // Mantém no máximo 200 itens no histórico
    if (_history.length > 200) {
      _history = _history.take(200).toList();
    }
    final encoded = jsonEncode(_history.map((a) => a.toJson()).toList());
    await prefs.setString('alerts_history', encoded);
  }

  void _addToHistory(AlertModel alert) {
    if (_historyEventIds.contains(alert.eventId)) return;
    _historyEventIds.add(alert.eventId);
    _history.insert(0, alert); // mais recente no topo
    _saveHistory();
  }

  Future<void> clearHistory() async {
    _history.clear();
    _historyEventIds.clear();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('alerts_history');
    notifyListeners();
  }

  Future<void> saveConfig({
    required String url,
    required String user,
    required String password,
    List<String>? hosts,
    Map<String, String>? locations,
    bool? notificationsEnabled,
    int? minSeverity,
    int? pollIntervalSeconds,
    bool? showResolved,
    bool? soundEnabled,
    bool? vibrationEnabled,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('zabbix_url', url);
    await prefs.setString('zabbix_user', user);
    await prefs.setString('zabbix_password', password);

    _url = url;
    _user = user;
    _password = password;

    if (hosts != null) {
      _hostsInteresse = hosts;
      await prefs.setStringList('hosts_interesse', hosts);
    }

    if (locations != null) {
      _locations = locations;
      for (final entry in locations.entries) {
        await prefs.setString('loc_${entry.key}', entry.value);
      }
    }

    if (notificationsEnabled != null) {
      _notificationsEnabled = notificationsEnabled;
      await prefs.setBool('notifications_enabled', notificationsEnabled);
    }
    if (minSeverity != null) {
      _minSeverity = minSeverity;
      await prefs.setInt('min_severity', minSeverity);
    }
    if (pollIntervalSeconds != null) {
      _pollIntervalSeconds = pollIntervalSeconds;
      await prefs.setInt('poll_interval', pollIntervalSeconds);
    }
    if (showResolved != null) {
      _showResolved = showResolved;
      await prefs.setBool('show_resolved', showResolved);
    }
    if (soundEnabled != null) {
      _soundEnabled = soundEnabled;
      await prefs.setBool('sound_enabled', soundEnabled);
    }
    if (vibrationEnabled != null) {
      _vibrationEnabled = vibrationEnabled;
      await prefs.setBool('vibration_enabled', vibrationEnabled);
    }

    _authToken = '';
    notifyListeners();
    startPolling();
  }

  Future<void> toggleNotifications() async {
    _notificationsEnabled = !_notificationsEnabled;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', _notificationsEnabled);
    notifyListeners();
  }

  Future<bool> login() async {
    try {
      final response = await http.post(
        Uri.parse(_url),
        headers: {'Content-Type': 'application/json-rpc'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'method': 'user.login',
          'params': {
            'username': _user,
            'password': _password,
          },
          'id': 1,
        }),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(response.body);
      if (data['error'] != null) {
        _error = data['error']['data'] ?? data['error']['message'];
        return false;
      }

      _authToken = data['result'];
      _error = null;
      return true;
    } catch (e) {
      _error = 'Erro de conexão: $e';
      return false;
    }
  }

  Future<void> fetchAlerts() async {
    if (!isConfigured) return;

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      if (_authToken.isEmpty) {
        final ok = await login();
        if (!ok) {
          _isLoading = false;
          notifyListeners();
          return;
        }
      }

      final response = await http.post(
        Uri.parse(_url),
        headers: {'Content-Type': 'application/json-rpc'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'method': 'problem.get',
          'params': {
            'output': ['eventid', 'objectid', 'name', 'severity', 'clock', 'r_eventid', 'opdata'],
            'selectHosts': ['host', 'name'],
            'recent': true,
            'sortfield': ['eventid'],
            'sortorder': 'DESC',
            'limit': 50,
          },
          'auth': _authToken,
          'id': 2,
        }),
      ).timeout(const Duration(seconds: 20));

      final data = jsonDecode(response.body);

      if (data['error'] != null) {
        if (data['error'].toString().contains('Session') ||
            data['error'].toString().contains('authorized')) {
          _authToken = '';
          await fetchAlerts();
          return;
        }
        _error = data['error']['data'] ?? 'Erro na API';
        _isLoading = false;
        notifyListeners();
        return;
      }

      final List results = data['result'] ?? [];
      final List<AlertModel> novos = [];

      for (final item in results) {
        final hosts = item['hosts'] as List? ?? [];
        if (hosts.isEmpty) continue;

        final hostName = (hosts[0]['name'] ?? '').toString().toUpperCase();
        final hostTech = (hosts[0]['host'] ?? '').toString().toUpperCase();

        bool isInteresting = false;
        String? location;
        for (final h in _hostsInteresse) {
          final hUpper = h.toUpperCase();
          if (hostName.contains(hUpper) || hostTech.contains(hUpper)) {
            isInteresting = true;
            location = _locations[h] ?? _locations[hUpper];
            break;
          }
        }

        if (!isInteresting) continue;

        final alert = AlertModel.fromZabbix(item, location: location);

        final sev = int.tryParse(alert.severity) ?? 0;
        if (sev < _minSeverity) continue;

        // Sempre adiciona ao histórico (mesmo resolvidos)
        _addToHistory(alert);

        if (alert.isResolved && !_showResolved) continue;

        novos.add(alert);

        if (_notificationsEnabled &&
            !_notifiedEventIds.contains(alert.eventId) &&
            !alert.isResolved) {
          _notifiedEventIds.add(alert.eventId);
          await NotificationService().showAlertNotification(
            alert,
            playSound: _soundEnabled,
            vibrate: _vibrationEnabled,
          );
        }
      }

      _alerts = novos;
      _error = null;
    } catch (e) {
      _error = 'Falha ao buscar alertas: $e';
    }

    _isLoading = false;
    notifyListeners();
  }

  void startPolling() {
    _timer?.cancel();
    fetchAlerts();
    _timer = Timer.periodic(
      Duration(seconds: _pollIntervalSeconds),
      (_) => fetchAlerts(),
    );
  }

  void stopPolling() {
    _timer?.cancel();
  }

  Future<void> sendTestNotification() async {
    final testAlert = AlertModel(
      eventId: 'test_${DateTime.now().millisecondsSinceEpoch}',
      name: 'Teste de notificação - Link COMEP',
      severity: '4',
      severityName: 'Alta',
      hostName: 'COMEP',
      hostTechnical: 'COMEP',
      clock: DateTime.now(),
      location: _locations['COMEP'],
    );
    await NotificationService().showAlertNotification(
      testAlert,
      playSound: _soundEnabled,
      vibrate: _vibrationEnabled,
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
